#include <assert.h>
#include "STFQNWScheduler.h"


STFQNWScheduler::STFQNWScheduler(long bytesPerSec)
{
  assert(0); // TBD
}


void 
STFQNWScheduler::waitMyTurn(int flowId, float weight, int lenToSend)
{
  assert(0); // TBD
}

long long 
STFQNWScheduler::signalNextDeadline(long long prevDeadline)
{
  assert(0); //TBD
}


