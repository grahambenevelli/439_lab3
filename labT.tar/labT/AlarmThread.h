#ifndef _ALARM_THREAD_
#define _ALARM_THREAD_
#include "NWScheduler.h"
void startAlarmThread(NWScheduler *scheduler);
#endif /* _ALARM_THREAD_ */
